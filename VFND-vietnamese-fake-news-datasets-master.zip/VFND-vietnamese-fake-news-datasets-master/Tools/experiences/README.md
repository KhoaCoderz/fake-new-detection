# Utils

Đây là tập hợp các file dùng trong thử nghiệm lấy tin tức giả và phân loại tin tức

1. [write-document.ipynb](): Hỗ trợ trích xuất các thông tin dữ liệu trong dataset
2. [make-csv.ipynb]():
3. [get-news.ipynb]()