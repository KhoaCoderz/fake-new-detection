# Các tin tức giả được dẫn và nguồn

VFDN_So_Fake_6: Bài viết nói về một sự kiện được xác nhận là tin tức giả: sự kiện "bác sĩ Khoa rút ống thở" trong giai đoạn tháng 8-9/2021 (giai đoạn phong tóa COVID-19)

VFDN_So_Fake_7: Tin tức không kiểm chứng

VFDN_So_Fake_8 - 10: Bài viết đưa ra thông tin giả về cái chết của một nhân vật công chúng được xác nhận là tin tức giả

VFDN_So_Fake_11: Tin giả đưa ra các đồn đoán vô căn cứ về sự kiện "Cựu thủ tướng Nhật bị ám sát"

VFDN_So_Fake_12: Thông tin giả về một công ty đồng hồ không có thật, hình ảnh lấy của sự kiện chìm tàu Kazu 1 tại Hokkaido, nguồn tham khảo: [Vụ chìm tàu du lịch Nhật Bản: Dần hé lộ những sai phạm nghiêm trọng](https://www.baogiaothong.vn/vu-chim-tau-du-lich-nhat-ban-dan-he-lo-nhung-sai-pham-nghiem-trong-192550632.htm), nguồn ảnh: [Ảnh người đàn ông quỳ](https://www.shinmai.co.jp/news/article/CNTS2022042701046)

VFDN_So_Fake_13: Thông tin giả như VFDN_So_Fake_12