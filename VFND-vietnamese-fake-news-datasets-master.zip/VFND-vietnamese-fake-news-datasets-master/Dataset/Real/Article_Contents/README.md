# Các tin tức thật được dẫn và nguồn

Cấu trúc của phần lưu trữ tin tức giả: __{Tên file}: {Tiêu đề/Link}__

Các thông tin trong các tin tức này có thể kiểm chứng được vì thế, nếu có bất kì sai sót nào mong được góp ý của mọi người.

VFND_Ac_Real_0: [Một phụ nữ bịt mặt bắt cóc cháu bé 5 tuổi bị người dân tóm gọn](https://laodong.vn/phap-luat/mot-phu-nu-bit-mat-bat-coc-chau-be-5-tuoi-bi-nguoi-dan-tom-gon-605391.ldo)

VFND_Ac_Real_1: [Tung tin "Mr Bean" qua đời để phát tán virus độc hại](https://news.zing.vn/tung-tin-mr-bean-qua-doi-de-phat-tan-virus-doc-hai-post861659.html)

VFND_Ac_Real_2: [Nhân chứng kể lại phút đối mặt với tên cướp ngân hàng](https://news.zing.vn/nhan-chung-ke-lai-phut-doi-mat-voi-ten-cuop-ngan-hang-post874648.html)

VFND_Ac_Real_3: [Hãng chuyển phát nhanh phá sản, khách từ Sài Gòn ra Hà Nội đòi tiền](https://news.zing.vn/hang-chuyen-phat-nhanh-pha-san-khach-tu-sai-gon-ra-ha-noi-doi-tien-post874640.html)

VFND_Ac_Real_4: [Go-Jek và Grab giành giật thị trường Indonesia ra sao?](https://news.zing.vn/go-jek-va-grab-gianh-giat-thi-truong-indonesia-ra-sao-post874114.html)

VFND_Ac_Real_5: [Không có chuyện thí điểm chữ viết 'Tiếq Việt' bậc đại học ở TP.HCM](https://news.zing.vn/khong-co-chuyen-thi-diem-chu-viet-tieq-viet-bac-dai-hoc-o-tphcm-post800493.html)

VFND_Ac_Real_6: [Bộ Công Thương kết luận Con Cưng có sai sót nhưng không bán hàng giả](https://news.zing.vn/bo-cong-thuong-ket-luan-con-cung-co-sai-sot-nhung-khong-ban-hang-gia-post869549.html)

VFND_Ac_Real_7: [Phát hiện văn phòng công chứng giả tại TP.HCM](https://thanhnien.vn/thoi-su/phat-hien-van-phong-cong-chung-gia-tai-tphcm-1008502.html)

VFND_Ac_Real_8: [Thông ngã trên đèo Prenn, giao thông tắc nghẽn 2 giờ](https://vnexpress.net/tin-tuc/thoi-su/thong-nga-tren-deo-prenn-giao-thong-tac-nghen-2-gio-3816674.html)

VFND_Ac_Real_9: [Thanh Bùi ôm vợ khóc trên sân khấu](https://giaitri.vnexpress.net/photo/lang-nhac/thanh-bui-om-vo-khoc-tren-san-khau-3685591.html)

VFND_Ac_Real_10: [Mưa lớn do bão Usagi gây ngập úng 70 ha rau ở Lâm Đồng](https://vnexpress.net/tin-tuc/thoi-su/mua-lon-do-bao-usagi-gay-ngap-ung-70-ha-rau-o-lam-dong-3845123.html)

VFND_Ac_Real_11: [Sài Gòn mưa như trút nước, cây đổ đè người tử vong](https://vnexpress.net/tin-tuc/thoi-su/sai-gon-mua-nhu-trut-nuoc-cay-do-de-nguoi-tu-vong-3844468.html)

VFND_Ac_Real_12: [Ba thanh niên đánh nữ nhân viên ở sân bay Thọ Xuân](https://vnexpress.net/tin-tuc/thoi-su/giao-thong/ba-thanh-nien-danh-nu-nhan-vien-o-san-bay-tho-xuan-3844038.html)

VFND_Ac_Real_13: [Nữ sinh lớp 5 trả lại iPhone X cùng tiền cho người đánh rơi](https://vnexpress.net/tin-tuc/giao-duc/nu-sinh-lop-5-tra-lai-iphone-x-cung-tien-cho-nguoi-danh-roi-3845596.html)

VFND_Ac_Real_14: [Cô giáo ở Quảng Bình bắt trò tát bạn học 230 cái](https://vnexpress.net/tin-tuc/giao-duc/co-giao-o-quang-binh-bat-tro-tat-ban-hoc-230-cai-3844000.html)

VFND_Ac_Real_15: [Hà Nội có thêm ba xe buýt mui trần 20 tỷ đồng](https://vnexpress.net/tin-tuc/thoi-su/giao-thong/ha-noi-co-them-ba-xe-buyt-mui-tran-20-ty-dong-3845972.html)

VFND_Ac_Real_16: [Hơn 55 tỷ đồng nâng cấp 8,5 km đại lộ Võ Văn Kiệt ở TP HCM](https://vnexpress.net/photo/giao-thong/hon-55-ty-dong-nang-cap-85-km-dai-lo-vo-van-kiet-o-tp-hcm-3843937.html)

VFND_Ac_Real_17: [Nhiều máy bay không thể đáp xuống Tân Sơn Nhất](https://vnexpress.net/tin-tuc/thoi-su/nhieu-may-bay-khong-the-dap-xuong-tan-son-nhat-3844571.html)

VFND_Ac_Real_18: [Đường Sài Gòn kẹt từ sáng đến trưa](https://vnexpress.net/photo/giao-thong/duong-sai-gon-ket-tu-sang-den-trua-3844817.html)

VFND_Ac_Real_19: [Khán giả phố đi bộ Nguyễn Huệ cuồng nhiệt cổ vũ tuyển Việt Nam](https://thethao.tuoitre.vn/khan-gia-pho-di-bo-nguyen-hue-cuong-nhiet-co-vu-tuyen-viet-nam-20181202190358909.htm)

VFND_Ac_Real_20: [Đường chạy của người phụ nữ cụt chân](https://tuoitre.vn/duong-chay-cua-nguoi-phu-nu-cut-chan-20181202091055776.htm)

VFND_Ac_Real_21: [Máy bay Vietjet gặp sự cố ở Buôn Ma Thuột mới chỉ bay 8 chặng](https://tuoitre.vn/may-bay-vietet-gap-su-co-o-buon-ma-thuot-moi-chi-bay-8-chang-20181130082541633.htm)

VFND_Ac_Real_22: [Người đàn ông chết khô ở máy dập có thể do đột quỵ](https://tuoitre.vn/nguoi-dan-ong-chet-kho-o-may-dap-co-the-do-dot-quy-20181202132400409.htm)

VFND_Ac_Real_23: [Bị cảnh báo giả, khách trên máy bay TP.HCM đi Hà Nội hoảng sợ](https://tuoitre.vn/bi-canh-bao-gia-khach-tren-may-bay-tp-hcm-di-ha-noi-hoang-so-20181120082517218.htm)

VFND_Ac_Real_24: [An Giang cấm sử dụng âm thanh dụ chim yến trong đêm](https://thanhnien.vn/thoi-su/an-giang-cam-su-dung-am-thanh-du-chim-yen-trong-dem-1029155.html)

VFND_Ac_Real_25: [Băng trộm SH đâm chết các 'hiệp sĩ': Tấm lòng người cha hiệp sĩ](https://thanhnien.vn/doi-song/bang-trom-sh-dam-chet-cac-hiep-si-tam-long-nguoi-cha-hiep-si-1029123.html)

VFND_Ac_Real_26: [Chiếc lốp thứ hai của máy bay Vietjet được tìm thấy](https://vnexpress.net/tin-tuc/thoi-su/chiec-lop-thu-hai-cua-may-bay-vietjet-duoc-tim-thay-3848017.html)

VFND_Ac_Real_27: [Sắp có tuyến buýt '5 sao' từ Tân Sơn Nhất đi Vũng Tàu](https://vnexpress.net/tin-tuc/thoi-su/giao-thong/sap-co-tuyen-buyt-5-sao-tu-tan-son-nhat-di-vung-tau-3847973.html)

VFND_Ac_Real_28: [Hành khách thoát khỏi chiếc máy bay bị rơi bánh như thế nào](https://vnexpress.net/tin-tuc/thoi-su/giao-thong/hanh-khach-thoat-khoi-chiec-may-bay-bi-roi-banh-nhu-the-nao-3847054.html)

VFND_Ac_Real_29: [Dòng người xếp hàng chờ lấy vé mua online trận Việt Nam](https://vnexpress.net/tin-tuc/thoi-su/dong-nguoi-xep-hang-cho-lay-ve-mua-online-tran-viet-nam-philippines-3847313.html)

VFND_Ac_Real_30: [Thu bằng lái 2 phi công VietJet sau sự cố máy bay văng bánh](https://news.zing.vn/thu-bang-lai-2-phi-cong-vietjet-sau-su-co-may-bay-vang-banh-post897027.html)

VFND_Ac_Real_31: [Đeo nhẫn... lưng chừng tay](https://thanhnien.vn/thoi-su/de-nghi-xu-ly-nghiem-lai-xe-o-to-di-lui-tren-cao-toc-1029336.htmlhttps://vnexpress.net/tin-tuc/giao-duc/bo-giao-duc-dieu-chinh-phuong-an-thi-thpt-quoc-gia-2019-3848989.html)

VFND_Ac_Real_32: [Sinh viên Sài Gòn ùn ùn đăng ký thi TOEIC từ rạng sáng](https://vnexpress.net/tin-tuc/giao-duc/sinh-vien-sai-gon-un-un-dang-ky-thi-toeic-tu-rang-sang-3848412.html)

VFND_Ac_Real_33: [9X Việt được công ty đắt giá nhất thế giới mời thực tập](https://vnexpress.net/tin-tuc/giao-duc/9x-viet-duoc-cong-ty-dat-gia-nhat-the-gioi-moi-thuc-tap-3847615.html)

VFND_Ac_Real_34: [Nam sinh quay lén bạn nữ tắm ở Đà Nẵng bị đuổi học](https://vnexpress.net/tin-tuc/giao-duc/nam-sinh-quay-len-ban-nu-tam-o-da-nang-bi-duoi-hoc-3848982.html)

VFND_Ac_Real_35: [Nhân viên an ninh sân bay Thọ Xuân bị phạt vì 'phản ứng chậm'](https://vnexpress.net/tin-tuc/thoi-su/nhan-vien-an-ninh-san-bay-tho-xuan-bi-phat-vi-phan-ung-cham-3848561.html)

VFND_Ac_Real_36: [Nghi phạm bắn chết Phó chủ tịch HĐND phường trộm 2 khẩu súng, 16 viên đạn](https://vnexpress.net/tin-tuc/phap-luat/nghi-pham-ban-chet-pho-chu-tich-hdnd-phuong-trom-2-khau-sung-16-vien-dan-3848868.html)

VFND_Ac_Real_37: [Phó chủ tịch HĐND phường ở Gia Lai bị bắn chết tại trụ sở](https://vnexpress.net/tin-tuc/phap-luat/pho-chu-tich-hdnd-phuong-o-gia-lai-bi-ban-chet-tai-tru-so-3848274.html)

VFND_Ac_Real_38: [Bạo loạn khiến Paris thiệt hại ít nhất 3 triệu USD](https://vnexpress.net/tin-tuc/the-gioi/bao-loan-khien-paris-thiet-hai-it-nhat-3-trieu-usd-3848973.html)

VFND_Ac_Real_39: [Khải Hoàn Môn tan hoang sau cuộc bạo loạn lớn nhất 5 thập kỷ ở Paris](https://vnexpress.net/photo/the-gioi/khai-hoan-mon-tan-hoang-sau-cuoc-bao-loan-lon-nhat-5-thap-ky-o-paris-3848714.html)

VFND_Ac_Real_40: [Hà Nội, Sài Gòn cờ rợp đường mừng chiến thắng của tuyển Việt Nam](https://vnexpress.net/tuong-thuat/thoi-su/ha-noi-sai-gon-co-rop-duong-mung-chien-thang-cua-tuyen-viet-nam-3848047.html)

VFND_Ac_Real_41: [Hai tài xế đánh nhau vì giành đường tại 'nút cổ chai' Hà Nội](https://vnexpress.net/tin-tuc/cong-dong/hai-tai-xe-danh-nhau-vi-gianh-duong-tai-nut-co-chai-ha-noi-3848712.html)

VFND_Ac_Real_42: [Ôtô 'chôn chân' vì bị chặn đầu bởi trăm xe máy đi ngược chiều ở Sài Gòn](https://vnexpress.net/tin-tuc/cong-dong/video/oto-chon-chan-vi-bi-chan-dau-boi-tram-xe-may-di-nguoc-chieu-o-sai-gon-3847590.html)

VFND_Ac_Real_43: [Phụ huynh tố cáo trường cho trẻ ăn rau thối, tôm ươn](https://vnexpress.net/tin-tuc/giao-duc/phu-huynh-to-cao-truong-cho-tre-an-rau-thoi-tom-uon-3849082.html)

VFND_Ac_Real_44: [Nhiều trường ở TP HCM thu sai quỹ hội phụ huynh](https://vnexpress.net/tin-tuc/giao-duc/nhieu-truong-o-tp-hcm-thu-sai-quy-hoi-phu-huynh-3663723.html)

VFND_Ac_Real_45: [Chủ đầu tư nói gì về chuyện BOT An Sương - An Lạc 'thu phí quá hạn' ?](https://thanhnien.vn/thoi-su/chu-dau-tu-noi-gi-ve-chuyen-bot-an-suong-an-lac-thu-phi-qua-han-1029810.html)

VFND_Ac_Real_46: [Cầu vượt biển dài nhất Việt Nam bị rải đinh dày đặc](https://vnexpress.net/tin-tuc/thoi-su/cau-vuot-bien-dai-nhat-viet-nam-bi-rai-dinh-day-dac-3849220.html)

VFND_Ac_Real_47: [Trung Quốc giảm nhập bưởi và sầu riêng Việt](https://kinhdoanh.vnexpress.net/tin-tuc/hang-hoa/trung-quoc-giam-nhap-buoi-va-sau-rieng-viet-3848788.html)

VFND_Ac_Real_48: [Ba du khách tử vong ở Đà Nẵng trúng chất độc ảnh hưởng tim mạch](https://vnexpress.net/tin-tuc/thoi-su/ba-du-khach-tu-vong-o-da-nang-trung-chat-doc-anh-huong-tim-mach-3849019.html)

VFND_Ac_Real_49: [Ôtô ở Sài Gòn cuốn hàng loạt người, xe máy vào gầm](https://vnexpress.net/tin-tuc/thoi-su/oto-o-sai-gon-cuon-hang-loat-nguoi-xe-may-vao-gam-3849793.html)

VFND_Ac_Real_50: ['Xã hội đen' Hải Phòng xây hàng trăm nhà trái phép trên đất quốc phòng](https://vnexpress.net/tin-tuc/thoi-su/xa-hoi-den-hai-phong-xay-hang-tram-nha-trai-phep-tren-dat-quoc-phong-3825660.html)

VFND_Ac_Real_51: [Nữ tiếp viên gốc Hoa bị chụp trộm gây sốt mạng xã hội](https://dulich.vnexpress.net/photo/quoc-te/nu-tiep-vien-goc-hoa-bi-chup-trom-gay-sot-mang-xa-hoi-3824611.html)

VFND_Ac_Real_52: [Xã hội đen Đài Loan mở tiệm mỳ miễn phí cho người nghèo](https://vnexpress.net/tin-tuc/the-gioi/cuoc-song-do-day/xa-hoi-den-dai-loan-mo-tiem-my-mien-phi-cho-nguoi-ngheo-3805449.html)

VFND_Ac_Real_53: [Khởi tố ông Nguyễn Hoài Nam - bí thư Quận ủy Quận 2](https://tuoitre.vn/khoi-to-ong-nguyen-hoai-nam-bi-thu-quan-uy-quan-2-20181208122830771.htm)

VFND_Ac_Real_54: [vũ khí kết nối người trẻ của Tổng thống Indonesia](https://vnexpress.net/tin-tuc/the-gioi/tu-lieu/mang-xa-hoi-vu-khi-ket-noi-nguoi-tre-cua-tong-thong-indonesia-3803721.html)

VFND_Ac_Real_55: [Ăn chênh 600 triệu đồng một suất mua nhà xã hội khu trung tâm](https://kinhdoanh.vnexpress.net/tin-tuc/bat-dong-san/an-chenh-600-trieu-dong-mot-suat-mua-nha-xa-hoi-khu-trung-tam-3847177.html)

VFND_Ac_Real_56: [Thừa Thiên Huế cảnh báo mưa lũ qua mạng xã hội](https://vnexpress.net/tin-tuc/thoi-su/thua-thien-hue-canh-bao-mua-lu-qua-mang-xa-hoi-3811210.html)

VFND_Ac_Real_57: [Tại sao Apple chưa bao giờ quảng cáo trên mạng xã hội](https://sohoa.vnexpress.net/tin-tuc/doi-song-so/tai-sao-apple-chua-bao-gio-quang-cao-tren-mang-xa-hoi-3809397.html)

VFND_Ac_Real_58: [Lao động nước ngoài ở Việt Nam phải đóng bảo hiểm xã hội](https://vnexpress.net/tin-tuc/thoi-su/lao-dong-nuoc-ngoai-o-viet-nam-phai-dong-bao-hiem-xa-hoi-3826169.html)

VFND_Ac_Real_59: [Người Việt ở Paris: Cuộc sống vẫn diễn ra bình thường bất chấp bạo loạn](https://vnexpress.net/tin-tuc/the-gioi/nguoi-viet-5-chau/nguoi-viet-o-paris-cuoc-song-van-dien-ra-binh-thuong-bat-chap-bao-loan-3849033.html)

VFND_Ac_Real_60: [Cuộc sống của những người Thủ Thiêm cố giữ đất](https://vnexpress.net/tin-tuc/thoi-su/cuoc-song-cua-nhung-nguoi-thu-thiem-co-giu-dat-3745415.html)

VFND_Ac_Real_61: [Cảnh đời người đàn ông Nhật sống mòn trên tiền thừa kế](https://doisong.vnexpress.net/tin-tuc/to-am/canh-doi-nguoi-dan-ong-nhat-song-mon-tren-tien-thua-ke-3841654.html)

VFND_Ac_Real_62: [Cuộc sống ở 'ốc đảo' biệt thự ngoại thành Hà Nội](https://doisong.vnexpress.net/tin-tuc/loi-song/cuoc-song-o-oc-dao-biet-thu-ngoai-thanh-ha-noi-3818370.html)

VFND_Ac_Real_63: [Vẻ xa xỉ của Song Hye Kyo khi đóng quý cô trâm anh thế phiệt](https://giaitri.vnexpress.net/tin-tuc/thoi-trang/lang-mot/ve-xa-xi-cua-song-hye-kyo-khi-dong-quy-co-tram-anh-the-phiet-3849647.html)

VFND_Ac_Real_64: [Thương em bị mẹ vợ đoạ đày, anh trai gây án giết người](https://vnexpress.net/tin-tuc/phap-luat/ho-so-pha-an/thuong-em-bi-me-vo-doa-day-anh-trai-gay-an-giet-nguoi-3837455.html)

VFND_Ac_Real_65: [Đội cảnh sát có khả năng siêu nhớ mặt tại Anh](https://vnexpress.net/tin-tuc/phap-luat/doi-canh-sat-co-kha-nang-sieu-nho-mat-tai-anh-3844578.html)

VFND_Ac_Real_66: [Người Hà Nội chen chân chụp ảnh trong vườn cúc hoạ mi](https://vnexpress.net/photo/thoi-su/nguoi-ha-noi-chen-chan-chup-anh-trong-vuon-cuc-hoa-mi-3844419.html)

VFND_Ac_Real_67: [Người Việt đã vỡ mộng xe giá rẻ?](https://vnexpress.net/tin-tuc/oto-xe-may/dien-dan/nguoi-viet-da-vo-mong-xe-gia-re-3769682.html)

VFND_Ac_Real_68: [Tài xế ép hàng loạt xe máy, ôtô nhập đúng làn ở Đà Nẵng](https://vnexpress.net/tin-tuc/cong-dong/video/tai-xe-ep-hang-loat-xe-may-oto-nhap-dung-lan-o-da-nang-3758654.html)

VFND_Ac_Real_69: [Bộ sưu tập xe trị giá 1,3 triệu USD của Neymar](https://vnexpress.net/photo/oto-xe-may/bo-suu-tap-xe-tri-gia-13-trieu-usd-cua-neymar-3767355.html)

VFND_Ac_Real_70: [Vì sao Toyota Vios tăng giá trong khi xe hãng khác giảm?](https://vnexpress.net/tin-tuc/oto-xe-may/dien-dan/vi-sao-toyota-vios-tang-gia-trong-khi-xe-hang-khac-giam-3786253.html)

VFND_Ac_Real_71: [Thói quen lái xe giúp tiết kiệm 25% nhiên liệu](https://vnexpress.net/tin-tuc/oto-xe-may/tu-van/thoi-quen-lai-xe-giup-tiet-kiem-25-nhien-lieu-3622374.html)

VFND_Ac_Real_72: [Cụ bà Nhật ăn cắp vặt để vào tù, trốn tránh cô đơn](https://vnexpress.net/tin-tuc/the-gioi/cuoc-song-do-day/cu-ba-nhat-an-cap-vat-de-vao-tu-tron-tranh-co-don-3724555.html)

VFND_Ac_Real_73: [Nam cảnh sát Mỹ truy đuổi nữ sinh viên để sàm sỡ](https://vnexpress.net/tin-tuc/phap-luat/ho-so-pha-an/nam-canh-sat-my-truy-duoi-nu-sinh-vien-de-sam-so-3760202.html)

VFND_Ac_Real_74: [Tài xế xe sang che biển số để lùi trên cao tốc](https://vnexpress.net/tin-tuc/oto-xe-may/tai-xe-xe-sang-che-bien-so-de-lui-tren-cao-toc-3776294.html)

VFND_Ac_Real_75: [Máy bay quay đầu để cấp cứu sản phụ người nước ngoài](https://vnexpress.net/tin-tuc/thoi-su/may-bay-quay-dau-de-cap-cuu-san-phu-nguoi-nuoc-ngoai-3750857.html)

VFND_Ac_Real_76: [Cô gái 17 tuổi được NASA đào tạo để đặt chân lên Sao Hỏa](https://vnexpress.net/tin-tuc/giao-duc/co-gai-17-tuoi-duoc-nasa-dao-tao-de-dat-chan-len-sao-hoa-3775543.html)

VFND_Ac_Real_77: [Thói quen Bill Gates đã từ bỏ để thành công](https://kinhdoanh.vnexpress.net/tin-tuc/quoc-te/thoi-quen-bill-gates-da-tu-bo-de-thanh-cong-3724397.html)

VFND_Ac_Real_78: [Giáo viên đề nghị bỏ thi trắc nghiệm môn Lịch sử](https://vnexpress.net/tin-tuc/giao-duc/giao-vien-de-nghi-bo-thi-trac-nghiem-mon-lich-su-3784662.html)

VFND_Ac_Real_79: [Sẽ bỏ quản lý dân cư bằng hộ khẩu](https://vnexpress.net/tin-tuc/phap-luat/se-bo-quan-ly-dan-cu-bang-ho-khau-3665172.html)

VFND_Ac_Real_80: [Bé gái bị cha cứa cổ khi muốn đi tập văn nghệ đêm trung thu](https://vnexpress.net/tin-tuc/phap-luat/be-gai-bi-cha-cua-co-khi-muon-di-tap-van-nghe-dem-trung-thu-3814980.html)

VFND_Ac_Real_81: [Người đi xe đạp điện chém chết tài xế ôtô ở Trung Quốc thoát tội](https://vnexpress.net/tin-tuc/the-gioi/cuoc-song-do-day/nguoi-di-xe-dap-dien-chem-chet-tai-xe-oto-o-trung-quoc-thoat-toi-3803024.html)

VFND_Ac_Real_82: [Đường đi bộ lát gỗ lim ven sông Hương sắp hoàn thành](https://vnexpress.net/tin-tuc/thoi-su/duong-di-bo-lat-go-lim-ven-song-huong-sap-hoan-thanh-3795346.html)

VFND_Ac_Real_83: [Cựu nữ chủ tịch xã 45 tuổi đi thi THPT quốc gia](https://vnexpress.net/tin-tuc/giao-duc/tuyen-sinh/cuu-nu-chu-tich-xa-45-tuoi-di-thi-thpt-quoc-gia-3768122.html)

VFND_Ac_Real_84: [Luật cho phép xe cứu hỏa được đi ngược chiều khi làm nhiệm vụ](https://vnexpress.net/tin-tuc/oto-xe-may/tu-van/luat-cho-phep-xe-cuu-hoa-duoc-di-nguoc-chieu-khi-lam-nhiem-vu-3724667.html)

VFND_Ac_Real_85: [Nguyễn Khắc Thủy tự nguyện đi thi hành án 3 năm tù](https://vnexpress.net/tin-tuc/phap-luat/nguyen-khac-thuy-tu-nguyen-di-thi-hanh-an-3-nam-tu-3765199.html)

VFND_Ac_Real_86: [TP HCM muốn có tuyến buýt từ Tân Sơn Nhất đi các tỉnh](https://vnexpress.net/tin-tuc/thoi-su/giao-thong/tp-hcm-muon-co-tuyen-buyt-tu-tan-son-nhat-di-cac-tinh-3767224.html)

VFND_Ac_Real_87: [Thanh Hoá chi gần 700 triệu cho ba cán bộ đi Mỹ xúc tiến đầu tư](https://vnexpress.net/tin-tuc/thoi-su/thanh-hoa-chi-gan-700-trieu-cho-ba-can-bo-di-my-xuc-tien-dau-tu-3804502.html)

VFND_Ac_Real_88: [Đại ca giang hồ bị bắn chết khi đi dằn mặt](https://vnexpress.net/tin-tuc/phap-luat/dai-ca-giang-ho-bi-ban-chet-khi-di-dan-mat-3813273.html)

VFND_Ac_Real_89: [Con không chịu đi học, mẹ Thái Lan bắt nhặt rác cả ngày](https://vnexpress.net/tin-tuc/giao-duc/con-khong-chiu-di-hoc-me-thai-lan-bat-nhat-rac-ca-ngay-3703551.html)

VFND_Ac_Real_90: [Ôtô đi ngược chiều bị phạt 800.000 đồng](https://vnexpress.net/tin-tuc/phap-luat/tu-van/oto-di-nguoc-chieu-bi-phat-800-000-dong-3533546.html)

VFND_Ac_Real_91: [Cha đẻ robot Sophia: Người máy sẽ có quyền kết hôn với con người](https://vnexpress.net/tin-tuc/khoa-hoc/cha-de-robot-sophia-nguoi-may-se-co-quyen-ket-hon-voi-con-nguoi-3754297.html)

VFND_Ac_Real_92: [Nghi phạm sát hại 3 người trong gia đình ở Tiền Giang bị bắt](https://vnexpress.net/tin-tuc/phap-luat/nghi-pham-sat-hai-3-nguoi-trong-gia-dinh-o-tien-giang-bi-bat-3792157.html)

VFND_Ac_Real_93: [Tài xế taxi tông người trông xe tử vong vì bị nhắc nhở](https://vnexpress.net/tin-tuc/phap-luat/tai-xe-taxi-tong-nguoi-trong-xe-tu-vong-vi-bi-nhac-nho-3801070.html)

VFND_Ac_Real_94: [Số người chết sau thảm họa ở Indonesia tăng lên 1.347](https://vnexpress.net/tin-tuc/the-gioi/so-nguoi-chet-sau-tham-hoa-o-indonesia-tang-len-1-374-3818377.html)

VFND_Ac_Real_95: [Ôtô Mercedes lật nhiều vòng trên đường Sài Gòn](https://vnexpress.net/tin-tuc/thoi-su/giao-thong/oto-mercedes-lat-nhieu-vong-tren-duong-sai-gon-3815162.html)

VFND_Ac_Real_96: [Nhiều tụ điểm thác loạn ở TP HCM bị xem xét điều tra](https://vnexpress.net/tin-tuc/phap-luat/nhieu-tu-diem-thac-loan-o-tp-hcm-bi-xem-xet-dieu-tra-3748324.html)

VFND_Ac_Real_97: [Trung Quốc hủy nhiều chuyến bay tới Thường Châu, CĐV Việt lo lắng](https://vnexpress.net/tin-tuc/the-gioi/nguoi-viet-5-chau/trung-quoc-huy-nhieu-chuyen-bay-toi-thuong-chau-cdv-viet-lo-lang-3704082.html)

VFND_Ac_Real_98: [TP HCM sẽ có thêm nhiều phố đi bộ](https://vnexpress.net/tin-tuc/thoi-su/tp-hcm-se-co-them-nhieu-pho-di-bo-3811204.html)

VFND_Ac_Real_99: [Nhiều người mẩn ngứa sau khi tắm biển ở Đà Nẵng](https://vnexpress.net/tin-tuc/thoi-su/nhieu-nguoi-man-ngua-sau-khi-tam-bien-o-da-nang-3772576.html)

VFND_Ac_Real_100: [Xả súng tại nhà thờ Mỹ, ít nhất 26 người thiệt mạng](https://vnexpress.net/tin-tuc/the-gioi/xa-sung-tai-nha-tho-my-it-nhat-26-nguoi-thiet-mang-3665999.html)

VFND_Ac_Real_101: [HLV Eriksson dự đoán tuyển VN sẽ đá bại Malaysia](https://thethao.tuoitre.vn/hlv-eriksson-du-doan-tuyen-vn-se-da-bai-malaysia-20181209114613393.htm)

VFND_Ac_Real_102: [Xuân Trường háo hức thi đấu trước 80.000 khán giả Malaysia](https://thethao.tuoitre.vn/xuan-truong-hao-huc-thi-dau-truoc-80-000-khan-gia-malaysia-20181209124745227.htm)

VFND_Ac_Real_103: [Mua vé trận chung kết: chen lấn, giẫm đạp, hỗn loạn, ngất xỉu](https://thethao.tuoitre.vn/mua-ve-tran-chung-ket-chen-lan-giam-dap-hon-loan-ngat-xiu-20181209090004845.htm)

VFND_Ac_Real_104: [Ông Lê Hoài Anh tiếp tục giữ chức tổng thư ký VFF khóa 8](https://thethao.tuoitre.vn/ong-le-hoai-anh-tiep-tuc-giu-chuc-tong-thu-ky-vff-khoa-8-20181209001626608.htm)

VFND_Ac_Real_105: [Đánh bại Djokovic, Zverev lần đầu vô địch Giải quần vợt ATP Finals](https://thethao.tuoitre.vn/danh-bai-dokovic-zverev-lan-dau-vo-dich-giai-quan-vot-atp-finals-20181119055342346.htm)

VFND_Ac_Real_106: ['Hoa hậu quần vợt' Bouchard trổ tài đá bóng](https://thethao.tuoitre.vn/hoa-hau-quan-vot-bouchard-tro-tai-da-bong-2018112221552504.htm)

VFND_Ac_Real_107: [“Quần vợt VN coi chừng lạc đường như Thái Lan”](https://thethao.tuoitre.vn/quan-vot-vn-coi-chung-lac-duong-nhu-thai-lan-821535.htm)

VFND_Ac_Real_108: [Federer đụng Djokovic ở bán kết Giải quần vợt Paris Masters](https://thethao.tuoitre.vn/federer-dung-dokovic-o-ban-ket-giai-quan-vot-paris-masters-20181103062334363.htm)

VFND_Ac_Real_109: [Nadal gặp Tsitsipas ở chung kết Giải quần vợt Barcelona mở rộng](https://thethao.tuoitre.vn/nadal-gap-tsitsipas-o-chung-ket-giai-quan-vot-barcelona-mo-rong-1439844.htm)

VFND_Ac_Real_110: [Khởi tố cặp “nữ quái” chuyên cung cấp ma túy, thuốc lắc](https://dantri.com.vn/phap-luat/khoi-to-cap-nu-quai-chuyen-cung-cap-ma-tuy-thuoc-lac-20181209204749864.htm)

VFND_Ac_Real_111: [Dùng dao đâm chết người vì xích mích lúc đổ xăng](https://dantri.com.vn/phap-luat/dung-dao-dam-chet-nguoi-vi-xich-mich-luc-do-xang-20181209202623487.htm)

VFND_Ac_Real_112: [Quên khóa ô tô, nữ tài xế bị "khoắng" sạch tài sản](https://dantri.com.vn/phap-luat/quen-khoa-o-to-nu-tai-xe-bi-khoang-sach-tai-san-20181209143646284.htm)

VFND_Ac_Real_113: [Lừa bán bé gái 14 tuổi, bắt luôn người giải cứu để đòi tiền chuộc](https://dantri.com.vn/phap-luat/lua-ban-be-gai-14-tuoi-bat-luon-nguoi-giai-cuu-de-doi-tien-chuoc-20181209122608572.htm)

VFND_Ac_Real_114: [Đòi nợ 60 triệu không được, ép nạn nhân viết giấy vay... 400 triệu](https://dantri.com.vn/phap-luat/doi-no-60-trieu-khong-duoc-ep-nan-nhan-viet-giay-vay-400-trieu-20181209083854909.htm)

VFND_Ac_Real_115: [Vụ chạy thận chết người: Cựu giám đốc bệnh viện bị truy tố từ 3-12 năm tù](https://dantri.com.vn/phap-luat/vu-chay-than-chet-nguoi-cuu-giam-doc-benh-vien-bi-truy-to-tu-3-12-nam-tu-20181209083714518.htm)

VFND_Ac_Real_116: [Sau ly hôn vợ, tình nhân đòi chia tay nên ra tay sát hại](https://dantri.com.vn/phap-luat/sau-ly-hon-vo-tinh-nhan-doi-chia-tay-nen-ra-tay-sat-hai-20181209082922084.htm)

VFND_Ac_Real_117: [Đuổi theo kẻ ném chất bẩn, chủ nhà bị gãy chân](https://dantri.com.vn/phap-luat/duoi-theo-ke-nem-chat-ban-chu-nha-bi-gay-chan-2018120908113454.htm)

VFND_Ac_Real_118: [Đối tượng cuối cùng trong vụ trốn khỏi trại tạm giam Kiên Giang đã bị bắt](https://dantri.com.vn/phap-luat/doi-tuong-cuoi-cung-trong-vu-tron-khoi-trai-tam-giam-kien-giang-da-bi-bat-20181209081958807.htm)

VFND_Ac_Real_119: [“Siêu máy bay” A350 sẽ chở CĐV Việt Nam đi Malaysia cổ vũ chung kết lượt đi](https://dantri.com.vn/the-thao/sieu-may-bay-a350-se-cho-cdv-viet-nam-di-malaysia-co-vu-chung-ket-luot-di-20181208082125017.htm)

VFND_Ac_Real_120: [Thưởng 20.000 USD cho đội tuyển cờ vua Việt Nam tại Olympiad 2018](https://dantri.com.vn/the-thao/thuong-20000-usd-cho-doi-tuyen-co-vua-viet-nam-tai-olympiad-2018-20181017151513152.htm)

VFND_Ac_Real_121: [Trường Sơn giành HCV tại giải cờ vua đồng đội thế giới 2018](https://dantri.com.vn/the-thao/truong-son-gianh-hcv-tai-giai-co-vua-dong-doi-the-gioi-2018-20181005221940293.htm)

VFND_Ac_Real_122: [Chuyện về chàng sinh viên Luật - Kiện tướng Lê Tuấn Minh](https://dantri.com.vn/the-thao/chuyen-ve-chang-sinh-vien-luat-kien-tuong-le-tuan-minh-20180320085855246.htm)

VFND_Ac_Real_123: [Tiền đạo Malaysia: “Tôi đã có cách vượt qua hàng thủ đội tuyển Việt Nam”](https://dantri.com.vn/the-thao/tien-dao-malaysia-toi-da-co-cach-vuot-qua-hang-thu-doi-tuyen-viet-nam-20181209191129676.htm)

VFND_Ac_Real_124: [WHO không chấp nhận kit test của Công ty Việt Á](https://thanhnien.vn/who-khong-chap-nhan-kit-test-cua-cong-ty-viet-a-post1413569.html)

VFND_Ac_Real_125: [Thực hư thông tin Nhật Bản cấm lò vi sóng từ cuối năm 2019 vì độc hại](https://www.anninhthudo.vn/thuc-hu-thong-tin-nhat-ban-cam-lo-vi-song-tu-cuoi-nam-2019-vi-doc-hai-post404236.antd)

VFND_Ac_Real_126: [Nhật Bản cấm lò vi sóng, phạt tù từ 5 đến 10 năm ai còn dùng lò vi sóng](https://tuoitre.vn/facebook-ran-ran-vu-nhat-ban-cam-lo-vi-song-cuoi-nam-nay-20190822135827808.htm)

VFND_Ac_Real_127: ['Nhật Bản cấm dùng lò vi sóng' là tin giả](https://vnexpress.net/nhat-ban-cam-dung-lo-vi-song-la-tin-gia-3977410.html)